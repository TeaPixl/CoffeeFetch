if __name__ == "__main__": # ran when -m specified
    from coffeefetch import fetch
    fetch.main()
